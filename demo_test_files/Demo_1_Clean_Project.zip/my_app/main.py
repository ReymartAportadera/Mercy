def main():
    print('Hello TrustFile!')
if __name__ == '__main__':
    main()
